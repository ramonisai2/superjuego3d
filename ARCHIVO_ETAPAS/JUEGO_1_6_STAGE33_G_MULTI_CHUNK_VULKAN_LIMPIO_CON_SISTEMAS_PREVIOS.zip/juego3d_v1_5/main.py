from motor_juegos import GameEngine, AudioManager, r3d, r2d, env
from motor_juegos.render_backend import create_render_backend
import os
from motor_juegos.render_api import FogConfig
from motor_juegos.frame_graph import RenderFrameGraph
import pygame
import random
import math
import multiprocessing
import time
from motor_juegos.render_mode_status import write_render_mode_log, get_render_mode_status
from motor_juegos.version_info import full_update_name, UPDATE_CODENAME, UPDATE_SUBTITLE
write_render_mode_log("main.py startup")

from game.player import Player
from game.enemy import Enemy, SlimeRemnant
from game.npc_manager import NPC
from game.combat import attack_enemy
from game.ui import draw_ui, draw_world_context, draw_npc_label, draw_npc_prompt, draw_npc_description, draw_npc_dialog, draw_npc_world_label, draw_z_target_ui, draw_z_target_marker
from game.save_system import save_game, load_game, load_game_data, apply_save_to_player, has_save, get_save_summary
from game.admin_hub import AdminHub
from game.debug_log import log_event, log_exception, log_throttled
from game.voxel_models import render_player_avatar

# ------------------------------
# Constantes
# ------------------------------
ANCHO = 1280
ALTO = 720
SEMILLA_MUNDO = random.randint(1, 1000000)  # se reemplaza desde el menu inicial si se continua o se elige nueva semilla
CHUNK_SIZE = 64
SUBDIVISIONES = 48
RADIO_VISION = 2                # chunks mas pequeños: mas anillo simple, cada pieza pesa menos
RADIO_DETALLE = 1               # menos agresivo: detalle en el chunk actual + 8 adyacentes
SUBDIVISIONES_LOD = 10          # LOD simple barato, un poco menos tosco
MAX_COLA_PETICIONES = 3         # cola moderada: prepara chunks cercanos sin saturar tanto
CHUNKS_COMPILAR_POR_FRAME = 1   # optimizacion G: compila 1 por frame para evitar picos
ENTITY_RENDER_DISTANCE = 125.0    # no dibujar entidades claramente lejanas
ENTITY_LABEL_DISTANCE = 48.0      # etiquetas solo cerca
SPAWN_CHUNK_X = 0
SPAWN_CHUNK_Z = 0
SPAWN_CENTER_X = SPAWN_CHUNK_X * CHUNK_SIZE + CHUNK_SIZE * 0.5
SPAWN_CENTER_Z = SPAWN_CHUNK_Z * CHUNK_SIZE + CHUNK_SIZE * 0.5

# ------------------------------
# Variables globales
# ------------------------------
engine = None
render_backend = None
render_graph = RenderFrameGraph()
audio = None
player = None
enemies = []
slime_remnants = []
npcs = []
npc_dialog = ""
npc_prompt = ""
npc_name_label = ""
npc_description = ""
npc_label_screen = None
z_target_screen = None
last_attack_time = 0.0
last_interact_time = 0.0
global_rocks = {}
pipe_juego = None
worker_process = None
mundo_chunks = {}
mundo_chunks_simple = {}
cola_de_peticiones = []
chunks_pendientes = {}
chunk_generándose_ahora = False
tiempo_log = 0.0
render_stats = {
    "chunks_detalle": 0,
    "chunks_lod": 0,
    "chunks_ocultos": 0,
    "entidades_render": 0,
    "entidades_ocultas": 0,
    "backend": "opengl",
}

current_fov = 45.0
target_fov = 45.0
last_attack_time = 0.0
attack_cooldown = 0.5
admin_hub = None
z_target = None
z_target_type = None
z_target_q_down = False
z_target_cycle_down = False

# ------------------------------
# Funciones auxiliares
# ------------------------------


def draw_simple_screen(engine, titulo, lineas=None, subtitulo=None):
    """Pantalla 2D simple para menú/carga usando el contexto OpenGL ya abierto."""
    if lineas is None:
        lineas = []
    if render_backend:
        render_backend.clear()
    r2d.begin_2d(ANCHO, ALTO)
    r2d.draw_rect_2d(0, 0, ANCHO, ALTO, (0.04, 0.07, 0.09))
    r2d.draw_rect_2d(160, 115, ANCHO - 320, ALTO - 230, (0.02, 0.025, 0.03))
    r2d.draw_text_2d(titulo, 205, 155, (240, 240, 220))
    y = 210
    if subtitulo:
        r2d.draw_text_2d(subtitulo, 205, y, (170, 220, 210))
        y += 48
    for linea in lineas:
        r2d.draw_text_2d(linea, 205, y, (220, 230, 220))
        y += 34
    r2d.end_2d()
    pygame.display.flip()


def show_loading_screen(mensaje="Cargando mundo..."):
    draw_simple_screen(engine, "JUEGO 1.6", [mensaje, "Generando chunks iniciales y preparando entidades...", f"Actualizacion: {full_update_name()}"], UPDATE_SUBTITLE)
    pygame.event.pump()


def show_start_menu(engine):
    """Menu inicial: continuar mundo guardado o empezar con otra semilla."""
    pygame.mouse.set_visible(True)
    pygame.event.set_grab(False)
    typing_seed = False
    seed_text = ""
    selected_seed = None
    save_summary = get_save_summary()

    while True:
        if selected_seed is not None:
            pygame.mouse.set_visible(False)
            pygame.event.set_grab(True)
            pygame.mouse.get_rel()
            return {"mode": "new", "seed": selected_seed, "save_data": None}

        lineas = []
        lineas.append(f"Actualizacion: {full_update_name()}")
        lineas.append(f"Nombre clave: {UPDATE_CODENAME}")
        lineas.append(UPDATE_SUBTITLE)
        lineas.append("")
        if save_summary:
            lineas.append(f"C - Continuar mundo guardado | Semilla {save_summary['seed']} | X {save_summary['x']:.1f} Z {save_summary['z']:.1f}")
            lineas.append(f"    Guardado: {save_summary.get('saved_at', 'desconocido')}")
        else:
            lineas.append("C - Continuar mundo guardado: no hay partida todavia")
        lineas.append("N - Nueva partida con semilla aleatoria")
        lineas.append("S - Escribir otra semilla manual")
        lineas.append("ESC - Salir")
        if typing_seed:
            lineas.append("")
            lineas.append("Escribe una semilla numerica y pulsa ENTER:")
            lineas.append(seed_text if seed_text else "_")
        else:
            lineas.append("")
            lineas.append("Controles dentro del juego: F5 guarda, F9 recarga, V camara, Q fijar objetivo")

        draw_simple_screen(engine, "Menu de Mundo", lineas, f"{full_update_name()} | Continuar o empezar")

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return {"mode": "quit", "seed": None, "save_data": None}
            if event.type == pygame.KEYDOWN:
                if typing_seed:
                    if event.key == pygame.K_RETURN:
                        if seed_text.strip():
                            try:
                                selected_seed = int(seed_text.strip())
                            except ValueError:
                                selected_seed = abs(hash(seed_text.strip())) % 1000000
                        typing_seed = False
                    elif event.key == pygame.K_ESCAPE:
                        typing_seed = False
                        seed_text = ""
                    elif event.key == pygame.K_BACKSPACE:
                        seed_text = seed_text[:-1]
                    else:
                        ch = event.unicode
                        if ch and (ch.isdigit() or (ch == '-' and not seed_text)):
                            seed_text += ch
                    continue

                if event.key == pygame.K_ESCAPE:
                    return {"mode": "quit", "seed": None, "save_data": None}
                if event.key == pygame.K_c and save_summary:
                    data = load_game_data()
                    pygame.mouse.set_visible(False)
                    pygame.event.set_grab(True)
                    pygame.mouse.get_rel()
                    return {"mode": "continue", "seed": int(data.get("seed", 1)), "save_data": data}
                if event.key == pygame.K_n:
                    selected_seed = random.randint(1, 1000000)
                if event.key == pygame.K_s:
                    typing_seed = True
                    seed_text = ""
        pygame.time.wait(16)

def player_chunk_coord(pos):
    return int(math.floor(pos / float(CHUNK_SIZE)))

def get_terrain_only(x, z):
    try:
        return env.get_cached_height_at(x, z, size=CHUNK_SIZE, subdivisions=SUBDIVISIONES, seed=SEMILLA_MUNDO)
    except:
        return env.get_terrain_height_at(x, z, seed=SEMILLA_MUNDO)

def get_total_height(x, z):
    h = get_terrain_only(x, z)
    if not math.isfinite(h):
        log_event("HEIGHT_NOT_FINITE", x=x, z=z, h=h)
    # Stage 28: para esta build de prueba, la superficie de lago actua como suelo
    # si queda por encima del terreno, evitando que el jugador/NPCs caminen bajo el agua.
    try:
        hay_agua, nivel_agua = env.get_water_surface_at(x, z, seed=SEMILLA_MUNDO)
        if hay_agua and nivel_agua > h:
            log_throttled("HEIGHT_WATER_SURFACE_USED", 2.0, x=x, z=z, terrain_h=h, water_level=nivel_agua)
            h = nivel_agua + 0.03
    except Exception as exc:
        log_exception("HEIGHT_WATER_CHECK_ERROR", exc)
    cx = int(math.floor(x / float(CHUNK_SIZE)))
    cz = int(math.floor(z / float(CHUNK_SIZE)))
    for dx in (-1, 0, 1):
        for dz in (-1, 0, 1):
            chunk_rocks = global_rocks.get((cx + dx, cz + dz))
            if not chunk_rocks:
                continue
            for rock in chunk_rocks:
                rx, ry, rz, sx, sy, sz = rock[:6]
                # Stage 30 Fix N: no usar objetos delgados/vegetacion como collider vertical.
                # Esto permite atravesar arboles/arbustos si entran por error a la lista de rocas.
                is_tall_skinny = sy > 1.4 and max(sx, sz) < 1.15
                is_tiny_bush = sy < 0.45 and max(sx, sz) < 0.75
                if is_tall_skinny or is_tiny_bush:
                    continue
                if abs(x - rx) <= sx/2 and abs(z - rz) <= sz/2:
                    h = max(h, ry + sy)
    return h


def is_water_position(x, z):
    """True si el punto cae dentro de agua visible; se usa para evitar spawns terrestres en lagos."""
    try:
        hay_agua, _ = env.get_water_surface_at(x, z, seed=SEMILLA_MUNDO)
        return bool(hay_agua)
    except Exception:
        return False


def update_player_world_context(dt):
    """Actualiza HUD de zona y modo nado/flotacion."""
    try:
        ctx = env.get_world_context_at(player.pos_x, player.pos_z, seed=SEMILLA_MUNDO)
    except Exception as exc:
        log_exception("WORLD_CONTEXT_ERROR", exc)
        ctx = {"biome": "Desconocido", "feature": "Sin datos", "layer": "?", "in_water": False}

    player.world_context = ctx
    in_water = bool(ctx.get("in_water", False))
    player.is_swimming = in_water

    if in_water:
        # Flotacion: el jugador no se hunde hasta el fondo, queda a nivel de superficie
        # con un cabeceo suave. Esto tambien sirve para depurar visualmente los lagos.
        phase = getattr(player, "swim_phase", 0.0) + dt * 3.2
        player.swim_phase = phase
        bob = math.sin(phase) * 0.08
        player.surface_offset = 0.82 + bob
        player.speed = min(player.speed, 3.2)
        player.velocity_y = 0.0
    else:
        player.surface_offset = player.player_height

def find_dry_spawn_position(base_x, base_z, min_radius, max_radius, attempts=40):
    """Busca una posición seca alrededor del jugador para NPCs/enemigos terrestres."""
    best = None
    for _ in range(attempts):
        angle = random.uniform(0, 2 * math.pi)
        radius = random.uniform(min_radius, max_radius)
        x = base_x + math.cos(angle) * radius
        z = base_z + math.sin(angle) * radius
        if is_water_position(x, z):
            continue
        y = get_total_height(x, z)
        best = (x, y, z)
        break
    if best is None:
        # Si todo falla, usa una posición cercana pero seca alrededor del spawn.
        x = base_x + min_radius
        z = base_z
        y = get_total_height(x, z)
        best = (x, y, z)
    return best


def find_safe_player_position(base_x, base_z, attempts=72, reason="unknown"):
    """
    Busca una zona seca y estable cerca del punto pedido.
    FIX H agrega log detallado para encontrar el culpable del ciclo de reaparicion.
    """
    log_event("SAFE_SEARCH_START", reason=reason, base_x=base_x, base_z=base_z, attempts=attempts, seed=SEMILLA_MUNDO)
    try:
        base_water = is_water_position(base_x, base_z)
        base_y = get_total_height(base_x, base_z)
        log_event("SAFE_BASE_CHECK", x=base_x, z=base_z, water=base_water, y=base_y, finite=math.isfinite(base_y))
        if (not base_water) and math.isfinite(base_y) and -20.0 < base_y < 160.0:
            log_event("SAFE_BASE_ACCEPTED", x=base_x, y=base_y, z=base_z)
            return base_x, base_y, base_z
    except Exception as exc:
        log_exception("SAFE_BASE_ERROR", exc)

    checked = 0
    for radius in (3.0, 6.0, 10.0, 16.0, 24.0, 36.0, 55.0):
        for i in range(attempts):
            checked += 1
            angle = (i / float(attempts)) * math.pi * 2.0 + random.uniform(-0.03, 0.03)
            x = base_x + math.cos(angle) * radius
            z = base_z + math.sin(angle) * radius
            water = is_water_position(x, z)
            if water:
                if checked <= 8 or checked % 40 == 0:
                    log_event("SAFE_CANDIDATE_REJECT_WATER", radius=radius, x=x, z=z)
                continue
            y = get_total_height(x, z)
            if not math.isfinite(y) or y < -20.0 or y > 160.0:
                if checked <= 8 or checked % 40 == 0:
                    log_event("SAFE_CANDIDATE_REJECT_HEIGHT", radius=radius, x=x, z=z, y=y)
                continue
            log_event("SAFE_CANDIDATE_ACCEPTED", checked=checked, radius=radius, x=x, y=y, z=z)
            return x, y, z

    log_event("SAFE_SEARCH_FALLBACK_ORIGIN", checked=checked)
    return find_dry_spawn_position(0.0, 0.0, 0.0, 18.0, attempts=80)

def set_player_respawn_point(player, x=None, z=None):
    old_x = getattr(player, "respawn_x", None)
    old_z = getattr(player, "respawn_z", None)
    player.respawn_x = float(player.pos_x if x is None else x)
    player.respawn_z = float(player.pos_z if z is None else z)
    player._last_safe_x = player.respawn_x
    player._last_safe_z = player.respawn_z
    try:
        player._last_safe_y = get_total_height(player.respawn_x, player.respawn_z) + player.player_height
    except Exception:
        player._last_safe_y = getattr(player, "pos_y", 10.0)
    log_event("RESPAWN_POINT_SET", old_x=old_x, old_z=old_z, new_x=player.respawn_x, new_z=player.respawn_z, safe_y=player._last_safe_y)


def world_to_screen(x, y, z):
    return render_backend.project_to_screen(x, y, z) if render_backend else None


def _entity_distance_2d(a_x, a_z, b_x, b_z):
    return math.hypot(a_x - b_x, a_z - b_z)

def _entity_alive(entity):
    return entity is not None and getattr(entity, "health", 1) > 0

def find_z_target(player, enemies, npcs, max_distance=22.0, max_angle_deg=85.0):
    """Busca el objetivo más útil cerca del centro de la mirada."""
    px = player.pos_x
    pz = player.pos_z
    yaw = math.radians(player.yaw)
    fx = math.cos(yaw)
    fz = math.sin(yaw)

    candidates = []
    for enemy in enemies:
        candidates.append(("enemy", enemy, 0.0))
    for npc in npcs:
        candidates.append(("npc", npc, 2.5))

    best = None
    best_score = 999999.0

    for kind, ent, penalty in candidates:
        dx = ent.x - px
        dz = ent.z - pz
        dist = math.hypot(dx, dz)
        if dist <= 0.01 or dist > max_distance:
            continue

        dot = (dx / dist) * fx + (dz / dist) * fz
        dot = max(-1.0, min(1.0, dot))
        angle = math.degrees(math.acos(dot))
        if angle > max_angle_deg:
            continue

        # Puntaje: prioriza estar cerca del centro de la cámara, luego distancia.
        score = angle * 1.8 + dist * 0.55 + penalty
        if score < best_score:
            best_score = score
            best = (kind, ent)

    return best

def update_z_target_lock(keys, player, enemies, npcs):
    """Q fija/suelta objetivo. Si el objetivo muere o se aleja, se libera."""
    global z_target, z_target_type, z_target_q_down

    q_down = bool(keys[pygame.K_q])
    if q_down and not z_target_q_down:
        if z_target is not None:
            z_target = None
            z_target_type = None
        else:
            found = find_z_target(player, enemies, npcs)
            if found:
                z_target_type, z_target = found
    z_target_q_down = q_down

    if z_target is None:
        return

    if z_target_type == "enemy":
        valid = z_target in enemies and _entity_alive(z_target)
    else:
        valid = z_target in npcs

    if not valid:
        z_target = None
        z_target_type = None
        return

    dist = _entity_distance_2d(player.pos_x, player.pos_z, z_target.x, z_target.z)
    if dist > 28.0:
        z_target = None
        z_target_type = None


def _z_target_candidates(player, enemies, npcs, max_distance=26.0, max_angle_deg=110.0):
    px = player.pos_x
    pz = player.pos_z
    yaw = math.radians(player.yaw)
    fx = math.cos(yaw)
    fz = math.sin(yaw)
    result = []

    for kind, collection, penalty in (("enemy", enemies, 0.0), ("npc", npcs, 3.5)):
        for ent in collection:
            dx = ent.x - px
            dz = ent.z - pz
            dist = math.hypot(dx, dz)
            if dist <= 0.01 or dist > max_distance:
                continue
            dot = (dx / dist) * fx + (dz / dist) * fz
            dot = max(-1.0, min(1.0, dot))
            angle = math.degrees(math.acos(dot))
            if angle > max_angle_deg:
                continue
            score = angle * 1.4 + dist * 0.45 + penalty
            result.append((score, kind, ent))

    result.sort(key=lambda item: item[0])
    return result

def cycle_z_target(player, enemies, npcs):
    """Cambia al siguiente objetivo visible con TAB."""
    global z_target, z_target_type
    candidates = _z_target_candidates(player, enemies, npcs)
    if not candidates:
        z_target = None
        z_target_type = None
        return

    if z_target is None:
        _, z_target_type, z_target = candidates[0]
        return

    current_index = -1
    for i, (_, kind, ent) in enumerate(candidates):
        if ent is z_target:
            current_index = i
            break

    next_index = (current_index + 1) % len(candidates)
    _, z_target_type, z_target = candidates[next_index]

def apply_z_target_camera(player, dt):
    """Suaviza la mirada hacia el objetivo fijado. En tercera persona se siente tipo lock-on."""
    global z_target
    if z_target is None:
        return

    dx = z_target.x - player.pos_x
    dz = z_target.z - player.pos_z
    dist = math.hypot(dx, dz)
    if dist <= 0.01:
        return

    target_y = getattr(z_target, "y", player.pos_y)
    dy = (target_y + 0.45) - player.pos_y

    desired_yaw = math.degrees(math.atan2(dz, dx))
    desired_pitch = math.degrees(math.atan2(dy, max(0.1, dist)))

    yaw_diff = (desired_yaw - player.yaw + 180.0) % 360.0 - 180.0
    player.yaw += yaw_diff * min(1.0, dt * 5.8)
    player.pitch += (desired_pitch - player.pitch) * min(1.0, dt * 4.2)
    player.pitch = max(-38.0, min(38.0, player.pitch))

def agregar_rocas_de_chunk(rock_data, cx, cz):
    global global_rocks
    global_rocks[(cx, cz)] = [rock + (cx, cz) for rock in rock_data]

def eliminar_rocas_de_chunk(cx, cz):
    global global_rocks
    if (cx, cz) in global_rocks:
        del global_rocks[(cx, cz)]

def administrar_rejilla_chunks(player_cx, player_cz, dir_x, dir_z):
    """Gestión menos agresiva de chunks.

    - El anillo visible se cubre con LOD simple.
    - Los 9 chunks alrededor del jugador usan detalle completo.
    - La predicción hacia adelante mantiene LOD simple para evitar zonas negras.
    """
    global cola_de_peticiones, mundo_chunks_simple
    chunks_simples = set()
    chunks_detalle = set()
    p_cx, p_cz = int(player_cx), int(player_cz)

    for dx in range(-RADIO_VISION, RADIO_VISION + 1):
        for dz in range(-RADIO_VISION, RADIO_VISION + 1):
            chunks_simples.add((p_cx + dx, p_cz + dz))

    # 9 chunks con detalle: actual + 8 adyacentes.
    for dx in range(-RADIO_DETALLE, RADIO_DETALLE + 1):
        for dz in range(-RADIO_DETALLE, RADIO_DETALLE + 1):
            chunks_detalle.add((p_cx + dx, p_cz + dz))
            chunks_simples.add((p_cx + dx, p_cz + dz))

    if dir_x != 0 or dir_z != 0:
        norm = math.hypot(dir_x, dir_z)
        if norm > 0:
            dir_x /= norm
            dir_z /= norm
            pred_cx = p_cx + int(round(dir_x))
            pred_cz = p_cz + int(round(dir_z))
            chunks_simples.add((pred_cx, pred_cz))

    for coord in chunks_simples:
        if coord not in mundo_chunks and coord not in mundo_chunks_simple:
            try:
                mundo_chunks_simple[coord] = render_backend.register_gpu_handle(env.build_simple_chunk_list(coord[0], coord[1], CHUNK_SIZE, SEMILLA_MUNDO, subdivisions=SUBDIVISIONES_LOD))
            except Exception as exc:
                print(f"[LOD] No se pudo crear chunk simple {coord}: {exc}")

    detalle_ordenado = sorted(chunks_detalle, key=lambda c: (c[0] - p_cx) ** 2 + (c[1] - p_cz) ** 2)
    for coord in detalle_ordenado:
        if coord not in mundo_chunks and coord not in cola_de_peticiones and coord not in chunks_pendientes:
            if len(cola_de_peticiones) < MAX_COLA_PETICIONES:
                cola_de_peticiones.append(coord)

    for coord in list(mundo_chunks.keys()):
        if coord not in chunks_detalle:
            render_backend.release_gpu_handle(mundo_chunks[coord])
            del mundo_chunks[coord]
            env.clean_cache_for_chunk(*coord)
            eliminar_rocas_de_chunk(*coord)
            if coord in cola_de_peticiones:
                cola_de_peticiones.remove(coord)
            if coord in chunks_pendientes:
                del chunks_pendientes[coord]

    for coord in list(mundo_chunks_simple.keys()):
        if coord not in chunks_simples or coord in mundo_chunks:
            render_backend.release_gpu_handle(mundo_chunks_simple[coord])
            del mundo_chunks_simple[coord]

def procesar_comunicacion_multiproceso():
    global chunk_generándose_ahora, cola_de_peticiones, chunks_pendientes
    if not chunk_generándose_ahora and cola_de_peticiones:
        proximo = cola_de_peticiones.pop(0)
        pipe_juego.send((int(proximo[0]), int(proximo[1])))
        chunk_generándose_ahora = True

    if chunk_generándose_ahora and pipe_juego.poll():
        try:
            recibido = pipe_juego.recv()
            if len(recibido) == 8:
                cx, cz, q, g, r, d, w, h = recibido
            else:
                cx, cz, q, g, r, d, h = recibido
                w = []
            env._height_cache[(int(cx), int(cz))] = h
            chunks_pendientes[(int(cx), int(cz))] = (q, g, r, d, w)
            agregar_rocas_de_chunk(r, cx, cz)
        except Exception as e:
            print(f"[ERROR] al recibir chunk: {e}")
        chunk_generándose_ahora = False

def compilar_un_chunk_pendiente():
    global chunks_pendientes, mundo_chunks, mundo_chunks_simple
    if not chunks_pendientes:
        return False
    px, _, pz, _, _, _ = player.get_camera_vectors()
    def distancia(coord):
        cx, cz = coord
        return (cx*CHUNK_SIZE - px)**2 + (cz*CHUNK_SIZE - pz)**2
    coord = min(chunks_pendientes.keys(), key=distancia)
    data = chunks_pendientes.pop(coord)
    if len(data) == 5:
        q, g, r, d, w = data
    else:
        q, g, r, d = data
        w = []
    mesh_data = env.build_chunk_mesh_data(coord[0], coord[1], q, g, r, d, w, size=CHUNK_SIZE, lod="detail")
    mundo_chunks[coord] = render_backend.upload_chunk_mesh(mesh_data)
    if coord in mundo_chunks_simple:
        render_backend.release_gpu_handle(mundo_chunks_simple[coord])
        del mundo_chunks_simple[coord]
    return True

# ------------------------------
# Bucle principal
# ------------------------------
def update(dt):
    global tiempo_log, target_fov, current_fov, last_attack_time, enemies, admin_hub, z_target, z_target_type, z_target_cycle_down, slime_remnants
    engine.handle_events()
    keys = pygame.key.get_pressed()
    current_time = pygame.time.get_ticks() / 1000.0

    # Admin Hub: F1 abre/cierra. Cuando está abierto, bloquea cámara/movimiento
    # para que los botones se puedan usar con mouse.
    if admin_hub:
        admin_hub.update(dt, keys, player, enemies, npcs, get_total_height, NPC, Enemy, SEMILLA_MUNDO)
        if admin_hub.visible:
            # Mantener entidades vivas, pero pausar controles de jugador/cámara.
            if admin_hub.ai_enabled:
                for npc in npcs:
                    npc.update(dt)
                for enemy in enemies[:]:
                    enemy.update(player, dt)
                    if enemy.health <= 0:
                        slime_remnants.append(enemy.create_remnant())
                        enemies.remove(enemy)
                for rem in slime_remnants[:]:
                    rem.update(dt)
                    if not rem.alive():
                        slime_remnants.remove(rem)
            return

    # Sprint
    if not hasattr(update, "is_sprinting"):
        update.is_sprinting = False
    if keys[pygame.K_LSHIFT] and player.stamina > 10:
        target_fov = 55.0
        player.speed = 10.0
        player.stamina -= 30 * dt
        if player.stamina < 0:
            player.stamina = 0
        update.is_sprinting = True
    else:
        if not keys[pygame.K_LSHIFT] or player.stamina <= 0:
            target_fov = 45.0
            player.speed = 5.0
            update.is_sprinting = False
        if player.stamina < 100:
            player.stamina += 15 * dt
            if player.stamina > 100:
                player.stamina = 100

    current_fov += (target_fov - current_fov) * 0.15
    if abs(current_fov - target_fov) < 0.01:
        current_fov = target_fov

    # Dirección del movimiento (para predicción de chunks)
    yaw_rad = math.radians(player.yaw)
    fx = math.cos(yaw_rad)
    fz = math.sin(yaw_rad)
    dx_move, dz_move = 0.0, 0.0
    if keys[pygame.K_w]:
        dx_move += fx; dz_move += fz
    if keys[pygame.K_s]:
        dx_move -= fx; dz_move -= fz
    if keys[pygame.K_a]:
        dx_move += fz; dz_move -= fx
    if keys[pygame.K_d]:
        dx_move -= fz; dz_move += fx
    norm = math.hypot(dx_move, dz_move)
    if norm > 0:
        dx_move /= norm; dz_move /= norm

    update_player_world_context(dt)
    player.process_mouse()
    player.process_keyboard(dt, get_total_height)
    update_player_world_context(dt)

    px, py, pz, _, _, _ = player.get_camera_vectors()
    chunk_actual_x = player_chunk_coord(px)
    chunk_actual_z = player_chunk_coord(pz)

    # Gestión de chunks (cada 50 ms)
    if tiempo_log >= 0.05:
        administrar_rejilla_chunks(chunk_actual_x, chunk_actual_z, dx_move, dz_move)
        procesar_comunicacion_multiproceso()
        for _ in range(CHUNKS_COMPILAR_POR_FRAME):
            if not compilar_un_chunk_pendiente():
                break

    # Ataque
    if pygame.mouse.get_pressed()[0] and (current_time - last_attack_time) >= attack_cooldown:
        locked_enemy = z_target if z_target_type == "enemy" else None
        hit_enemy = attack_enemy(player, enemies, locked_target=locked_enemy, attack_range=3.2)
        if hit_enemy:
            if audio and hasattr(audio, 'play_sound'):
                audio.play_sound("golpe", volume=0.7)
            last_attack_time = current_time
            if z_target_type == "enemy" and z_target is not None and z_target not in enemies:
                z_target = None
                z_target_type = None

    # Selección visual del enemigo cercano y Z Targeting.
    for enemy in enemies:
        enemy.selected = False
        enemy.z_locked = False
    for npc in npcs:
        npc.z_locked = False

    close_enemy = None
    close_enemy_dist = 999999.0
    for enemy in enemies:
        ed = math.hypot(px - enemy.x, pz - enemy.z)
        if ed < 4.0 and ed < close_enemy_dist:
            close_enemy = enemy
            close_enemy_dist = ed
    if close_enemy is not None:
        close_enemy.selected = True

    if z_target is not None:
        if z_target_type == "enemy":
            z_target.selected = True
        z_target.z_locked = True

    # Interacción con NPCs
    global npc_dialog, npc_prompt, npc_name_label, npc_description, last_interact_time
    npc_prompt = ""
    npc_name_label = ""
    npc_description = ""
    for npc in npcs:
        npc.highlight = False
    global npc_label_screen
    npc_label_screen = None
    for npc in npcs:
        dist = math.hypot(px - npc.x, pz - npc.z)
        if dist < 4.0:
            npc_name_label = f"{npc.nombre} {npc.titulo}"
            npc_description = npc.descripcion
            npc_prompt = f"Pulsa botón E para interactuar con {npc.nombre}"
            npc.highlight = True
            npc.screen_label = None
            if keys[pygame.K_e] and (current_time - last_interact_time) >= 0.35:
                npc_dialog = npc.interactuar()
                last_interact_time = current_time
            break

    # Actualizar entidades. El Admin Hub puede pausar la IA.
    ai_active = True
    if admin_hub:
        ai_active = admin_hub.ai_enabled

    if ai_active:
        for npc in npcs:
            npc.update(dt)

        for enemy in enemies[:]:
            enemy.update(player, dt)
            if enemy.health <= 0:
                slime_remnants.append(enemy.create_remnant())
                enemies.remove(enemy)

    for rem in slime_remnants[:]:
        rem.update(dt)
        if not rem.alive():
            slime_remnants.remove(rem)

    # Guardado / carga
    if keys[pygame.K_F5]:
        save_game(player, SEMILLA_MUNDO)
        print(f"[SAVE] Mundo guardado. Semilla={SEMILLA_MUNDO} X={player.pos_x:.1f} Z={player.pos_z:.1f}")
        pygame.time.wait(200)
    if keys[pygame.K_F9]:
        data = load_game_data()
        if data and int(data.get("seed", SEMILLA_MUNDO)) == int(SEMILLA_MUNDO):
            apply_save_to_player(player, data)
            log_event("F9_RELOAD_RAW", x=player.pos_x, y=player.pos_y, z=player.pos_z, health=player.health)
            safe_x, suelo, safe_z = find_safe_player_position(player.pos_x, player.pos_z, reason="f9_reload")
            player.pos_x = safe_x
            player.pos_z = safe_z
            player.pos_y = suelo + player.player_height + 0.08
            player.velocity_y = 0
            player.is_grounded = True
            player._last_safe_x = player.pos_x
            player._last_safe_y = player.pos_y
            player._last_safe_z = player.pos_z
            set_player_respawn_point(player, player.pos_x, player.pos_z)
            print(f"[LOAD] Partida recargada. X={player.pos_x:.1f} Z={player.pos_z:.1f}")
        elif data:
            print("[LOAD] La partida guardada usa otra semilla. Reinicia y usa Continuar.")
        else:
            print("[LOAD] No hay partida guardada.")
        pygame.time.wait(200)

    # Log cada 0.5s
    tiempo_log += dt
    if tiempo_log >= 0.5:
        print(f"[INFO] FOV: {current_fov:.1f} | Chunk: ({chunk_actual_x},{chunk_actual_z}) | Vida: {player.health:.0f} | Stamina: {player.stamina:.0f} | Enemigos: {len(enemies)}")
        tiempo_log = 0.0

def render_3d():
    global current_fov, z_target_screen, render_stats, npc_label_screen
    z_target_screen = None
    npc_label_screen = None
    frame_stats = render_backend.begin_frame() if render_backend else None
    render_stats = frame_stats.as_dict() if frame_stats else {
        "chunks_detalle": 0,
        "chunks_lod": 0,
        "chunks_ocultos": 0,
        "entidades_render": 0,
        "entidades_ocultas": 0,
        "entidades_transparentes": 0,
        "backend": "opengl",
        "render_passes": 0,
        "render_packets": 0,
    }

    r3d.setup_perspective(current_fov, ANCHO / ALTO, 0.1, 400.0)
    px, py, pz, lx, ly, lz = player.get_camera_vectors()
    r3d.setup_camera(px, py, pz, lx, ly, lz)

    color_horizonte = [0.75, 0.88, 1.0]
    r3d.setup_fog(color_horizonte)
    render_backend.configure_fog(FogConfig(tuple(color_horizonte), 60.0, 180.0))
    render_backend.draw_skybox(env, px, py, pz, size=300.0)

    # FrameGraph: primero armamos paquetes visibles y despues los ejecutamos.
    # Esto prepara el motor para command buffers/RenderPasses de Vulkan.
    render_graph.begin_frame()
    for (cx, cz), id_list in mundo_chunks_simple.items():
        if (cx, cz) in mundo_chunks:
            continue
        if render_backend.is_chunk_visible(env, cx, cz, px, pz, lx, lz, size=CHUNK_SIZE, max_distance=CHUNK_SIZE * (RADIO_VISION + 1.8)):
            render_graph.add_chunk((cx, cz), id_list, lod="lod")
        else:
            render_stats["chunks_ocultos"] += 1

    for (cx, cz), id_list in mundo_chunks.items():
        if render_backend.is_chunk_visible(env, cx, cz, px, pz, lx, lz, size=CHUNK_SIZE, max_distance=CHUNK_SIZE * (RADIO_VISION + 1.8)):
            render_graph.add_chunk((cx, cz), id_list, lod="detail")
        else:
            render_stats["chunks_ocultos"] += 1

    # El jugador y las entidades se agregan al FrameGraph como paquetes.
    # Esto prepara el camino para command buffers Vulkan sin romper el render actual.
    if getattr(player, "camera_mode", "first") == "third":
        render_graph.add_entity(
            "player", player,
            render_fn=lambda player=player: render_player_avatar(
                player.pos_x,
                player.pos_y - player.player_height,
                player.pos_z,
                yaw=getattr(player, "visual_yaw", player.yaw + 90.0),
                walk_phase=getattr(player, "walk_phase", 0.0),
                move_amount=getattr(player, "move_amount", 0.0),
                swimming=getattr(player, "is_swimming", False),
            ),
            transparent=False, priority=-5
        )

    for rem in slime_remnants:
        if env.is_point_visible_for_render(rem.x, rem.z, px, pz, lx, lz, max_distance=ENTITY_RENDER_DISTANCE):
            render_graph.add_entity("slime_remnant", rem, render_fn=lambda rem=rem: rem.render(), transparent=True, priority=5)
        else:
            render_stats["entidades_ocultas"] += 1

    for enemy in enemies:
        locked = bool(getattr(enemy, "z_locked", False))
        visible = locked or env.is_point_visible_for_render(enemy.x, enemy.z, px, pz, lx, lz, max_distance=ENTITY_RENDER_DISTANCE)
        if visible:
            render_graph.add_entity("enemy", enemy, render_fn=lambda enemy=enemy: enemy.render(), transparent=False)
        else:
            render_stats["entidades_ocultas"] += 1
        if locked:
            z_target_screen = world_to_screen(enemy.x, enemy.y + 0.9, enemy.z)

    for npc in npcs:
        locked = bool(getattr(npc, "z_locked", False))
        highlighted = bool(npc.highlight)
        visible = locked or highlighted or env.is_point_visible_for_render(npc.x, npc.z, px, pz, lx, lz, max_distance=ENTITY_RENDER_DISTANCE)
        if visible:
            render_graph.add_entity(
                "npc", npc,
                render_fn=lambda npc=npc, highlighted=highlighted, locked=locked: npc.render(
                    highlight=bool(highlighted or locked),
                    debug_hitbox=bool(highlighted and admin_hub and admin_hub.visible)
                ),
                transparent=False
            )
        else:
            render_stats["entidades_ocultas"] += 1

        if highlighted:
            # Las etiquetas en mundo se calculan sólo cerca para ahorrar proyección 2D.
            dx = npc.x - player.pos_x
            dz = npc.z - player.pos_z
            if dx * dx + dz * dz <= ENTITY_LABEL_DISTANCE * ENTITY_LABEL_DISTANCE:
                npc.screen_label = world_to_screen(npc.x, npc.y + (npc.height if hasattr(npc, 'height') else 1.6) + 0.15, npc.z)
                if npc.screen_label is not None:
                    npc_label_screen = npc.screen_label
        if locked:
            z_target_screen = world_to_screen(npc.x, npc.y + 2.1, npc.z)

    render_graph.execute(render_backend, render_stats)
    render_stats.update(render_graph.as_stats())

    r3d.disable_fog()

def render_2d():
    r2d.begin_2d(ANCHO, ALTO)
    draw_ui(player)
    draw_world_context(player)
    if admin_hub and admin_hub.visible:
        fps = engine.clock.get_fps() if engine and hasattr(engine, "clock") else 0
        r2d.draw_text_2d(
            f"Render[{render_stats.get('backend','opengl')}]: {fps:.0f} FPS | chunks D:{render_stats.get('chunks_detalle',0)} LOD:{render_stats.get('chunks_lod',0)} ocultos:{render_stats.get('chunks_ocultos',0)} | ent:{render_stats.get('entidades_render',0)}/{render_stats.get('entidades_ocultas',0)}",
            24, 132, (190, 235, 210)
        )
        r2d.draw_text_2d(
            f"Mesh: V:{render_stats.get('mesh_vertices',0)} I:{render_stats.get('mesh_indices',0)} Q:{render_stats.get('mesh_quads',0)} Batches:{render_stats.get('material_batches',0)} RAM~GPU:{render_stats.get('mesh_bytes',0)//1024}KB Uploads:{render_stats.get('uploads_frame',0)} | Pass:{render_stats.get('render_passes',0)} Pack:{render_stats.get('render_packets',0)} TransEnt:{render_stats.get('entidades_transparentes',0)}",
            24, 154, (185, 220, 245)
        )
        r2d.draw_text_2d(
            f"Instances: total:{render_stats.get('instance_total',0)} kinds:{render_stats.get('instance_kinds',0)} transp:{render_stats.get('instance_transparent',0)} player:{render_stats.get('instance_player',0)} enemy:{render_stats.get('instance_enemy',0)} npc:{render_stats.get('instance_npc',0)} StaticDraw:{render_stats.get('entidades_staticmesh',0)} Debug:{render_stats.get('static_entity_debug',0)}",
            24, 176, (220, 210, 245)
        )
        r2d.draw_text_2d(
            f"VulkanPrep: probe:{render_stats.get('vulkan_probe_ok',0)} tri:{render_stats.get('vulkan_triangle_ok',0)} chunk:{render_stats.get('vulkan_chunk_upload_ok',0)} mem:{render_stats.get('vulkan_memory_ok',0)} map:{render_stats.get('vulkan_staging_mapped',0)} cmd:{render_stats.get('vulkan_command_ok',0)} draw:{render_stats.get('vulkan_draw_ok',0)} rp:{render_stats.get('vulkan_render_pass_plan',0)} pipe:{render_stats.get('vulkan_pipeline_plan',0)} idx:{render_stats.get('vulkan_draw_indexed_plan',0)} sh:{render_stats.get('vulkan_shader_ok',0)} spv:{render_stats.get('vulkan_spirv_generated',0)} mods:{render_stats.get('vulkan_shader_modules',0)} layout:{render_stats.get('vulkan_pipeline_layout_ok',0)} fb:{render_stats.get('vulkan_framebuffer_ok',0)} begin:{render_stats.get('vulkan_renderpass_begin_ok',0)} didx:{render_stats.get('vulkan_draw_indexed_recorded',0)} comp:{render_stats.get('vulkan_shader_compiler',0)} shKB:{render_stats.get('vulkan_shader_bytes',0)//1024} copy:{render_stats.get('vulkan_copy_commands',0)} sub:{render_stats.get('vulkan_submits',0)} writeKB:{render_stats.get('vulkan_staging_write_kb',0)} allocKB:{render_stats.get('vulkan_alloc_kb',0)} vkKB:{render_stats.get('vulkan_upload_bytes',0)//1024} dev:{render_stats.get('vulkan_devices',0)}",
            24, 198, (245, 220, 160)
        )
    r2d.draw_rect_2d((ANCHO // 2) - 2, (ALTO // 2) - 2, 4, 4, (1, 1, 1))
    draw_npc_label(npc_name_label)
    draw_npc_prompt(npc_prompt)
    draw_npc_description(npc_description)
    draw_npc_dialog(npc_dialog)
    if npc_label_screen:
        draw_npc_world_label(npc_name_label, npc_label_screen[0], npc_label_screen[1])

    draw_z_target_ui(z_target, z_target_type)
    draw_z_target_marker(z_target_screen)

    if admin_hub:
        fps = engine.clock.get_fps() if engine and hasattr(engine, "clock") else 0
        admin_hub.draw(player, enemies, npcs, fps)

    r2d.end_2d()


def preload_initial_chunks(base_cx, base_cz):
    """Pantalla de carga menos agresiva: LOD alrededor y 9 chunks detallados iniciales."""
    global mundo_chunks, mundo_chunks_simple
    lod_coords = []
    for dx in range(-RADIO_VISION, RADIO_VISION + 1):
        for dz in range(-RADIO_VISION, RADIO_VISION + 1):
            lod_coords.append((base_cx + dx, base_cz + dz))
    lod_coords.sort(key=lambda coord: (coord[0] - base_cx) ** 2 + (coord[1] - base_cz) ** 2)

    detail_coords = []
    for dx in range(-RADIO_DETALLE, RADIO_DETALLE + 1):
        for dz in range(-RADIO_DETALLE, RADIO_DETALLE + 1):
            detail_coords.append((base_cx + dx, base_cz + dz))
    detail_coords.sort(key=lambda coord: (coord[0] - base_cx) ** 2 + (coord[1] - base_cz) ** 2)

    total = len(lod_coords) + len(detail_coords)
    step_num = 0
    for coord in lod_coords:
        step_num += 1
        show_loading_screen(f"LOD alrededor {step_num}/{total}...")
        pygame.event.pump()
        if coord not in mundo_chunks_simple and coord not in mundo_chunks:
            try:
                mundo_chunks_simple[coord] = render_backend.register_gpu_handle(env.build_simple_chunk_list(coord[0], coord[1], CHUNK_SIZE, SEMILLA_MUNDO, subdivisions=SUBDIVISIONES_LOD))
            except Exception as exc:
                print(f"[PRELOAD] Error creando LOD {coord}: {exc}")

    for coord in detail_coords:
        step_num += 1
        show_loading_screen(f"Detalle 9 chunks cercanos {step_num}/{total}...")
        pygame.event.pump()
        try:
            cx, cz, q, g, r, d, w, h = env.calculate_chunk_data_background(coord[0], coord[1], CHUNK_SIZE, SUBDIVISIONES, SEMILLA_MUNDO)
            env._height_cache[(int(cx), int(cz))] = h
            agregar_rocas_de_chunk(r, cx, cz)
            mesh_data = env.build_chunk_mesh_data(cx, cz, q, g, r, d, w, size=CHUNK_SIZE, lod="detail", height_map=h)
            mundo_chunks[(int(cx), int(cz))] = render_backend.upload_chunk_mesh(mesh_data)
            if coord in mundo_chunks_simple:
                render_backend.release_gpu_handle(mundo_chunks_simple[coord])
                del mundo_chunks_simple[coord]
        except Exception as exc:
            print(f"[PRELOAD] Error creando detalle {coord}: {exc}")

# ------------------------------
# Inicio
# ------------------------------
if __name__ == "__main__":
    multiprocessing.freeze_support()
    engine = GameEngine(ANCHO, ALTO, "JUEGO 1.6 - Stage33 F Primer Bloque Visible")
    render_backend = create_render_backend(os.environ.get("JUEGO_RENDER_BACKEND", "opengl"))

    menu_result = show_start_menu(engine)
    if menu_result.get("mode") == "quit":
        pygame.quit()
        raise SystemExit

    SEMILLA_MUNDO = int(menu_result.get("seed") or random.randint(1, 1000000))
    log_event("GAME_START", mode=menu_result.get("mode"), seed=SEMILLA_MUNDO, has_save=bool(menu_result.get("save_data")))
    show_loading_screen(f"Cargando semilla {SEMILLA_MUNDO}...")

    audio = AudioManager()
    player = Player(SPAWN_CENTER_X, 15.0, SPAWN_CENTER_Z, get_total_height)
    # FIX Q: permite que el movimiento sepa si el siguiente paso es agua.
    # Así la superficie del lago no se interpreta como una pared/meseta.
    player.water_probe_func = is_water_position
    loaded_save_data = menu_result.get("save_data")
    if loaded_save_data:
        log_event("LOAD_SAVE_RAW", x=loaded_save_data.get("x"), y=loaded_save_data.get("y"), z=loaded_save_data.get("z"),
                  health=loaded_save_data.get("health"), seed=loaded_save_data.get("seed"))
        apply_save_to_player(player, loaded_save_data)
        log_event("LOAD_SAVE_APPLIED", x=player.pos_x, y=player.pos_y, z=player.pos_z, health=player.health)
        safe_x, suelo, safe_z = find_safe_player_position(player.pos_x, player.pos_z, reason="continue_save")
        player.pos_x = safe_x
        player.pos_z = safe_z
        player.pos_y = suelo + player.player_height + 0.08
        player.velocity_y = 0
        player.is_grounded = True
        player._last_safe_x = player.pos_x
        player._last_safe_y = player.pos_y
        player._last_safe_z = player.pos_z
    else:
        safe_x, suelo, safe_z = find_safe_player_position(SPAWN_CENTER_X, SPAWN_CENTER_Z, reason="new_world_center_chunk")
        player.pos_x = safe_x
        player.pos_z = safe_z
        player.pos_y = suelo + player.player_height + 0.08
        player.is_grounded = True
        player._last_safe_x = player.pos_x
        player._last_safe_y = player.pos_y
        player._last_safe_z = player.pos_z
    set_player_respawn_point(player, player.pos_x, player.pos_z)
    admin_hub = AdminHub(ANCHO, ALTO)

    try:
        audio.load_music("musica_fondo.mp3")
        audio.play_music(loops=-1, volume=0.2)
    except:
        pass
    try:
        audio.load_sound_effect("golpe", "golpe.wav")
        audio.load_sound_effect("salto", "sonido_salto.wav")
    except:
        pass

    # Enemigos lejos del jugador/spawn actual.
    # FIX E: los terrestres no se generan sobre lagos/charcas.
    enemies = []
    for _ in range(2):
        x, y, z = find_dry_spawn_position(player.pos_x, player.pos_z, 60, 100)
        enemy = Enemy(x, y, z, get_total_height)
        enemy.lock_spawn_biome_color(SEMILLA_MUNDO)
        enemies.append(enemy)

    # Crear un NPC interactivo cerca del jugador/spawn actual.
    # FIX E: NPC terrestre evita nacer dentro del agua.
    npcs = []
    npc_spawn_x, npc_spawn_y, npc_spawn_z = find_dry_spawn_position(player.pos_x, player.pos_z, 5.0, 12.0)
    npc = NPC(123456, npc_spawn_x, npc_spawn_z, npc_spawn_y + 0.8)
    npc.terrain_height_func = get_total_height
    npc.wander_radius = 12.0
    npc.target_x = npc_spawn_x
    npc.target_z = npc_spawn_z
    npcs.append(npc)

    # Configurar multiproceso
    pipe_juego, pipe_worker = multiprocessing.Pipe()
    worker_process = multiprocessing.Process(
        target=env.terrain_worker_process,
        args=(pipe_worker, CHUNK_SIZE, SUBDIVISIONES, SEMILLA_MUNDO)
    )
    worker_process.daemon = True
    worker_process.start()

    print("[INICIO] Pantalla de carga: preparando chunks iniciales...")
    base_cx = player_chunk_coord(player.pos_x)
    base_cz = player_chunk_coord(player.pos_z)
    preload_initial_chunks(base_cx, base_cz)

    show_loading_screen("Listo. Entrando al mundo...")
    pygame.time.wait(250)
    print(f"[INICIO] Listo. Semilla={SEMILLA_MUNDO}. {len(enemies)} enemigos.")
    engine.run(update, render_2d, render_3d)
