"""Informacion visible de version/actualizacion."""

GAME_VERSION = "JUEGO 1.6"
STAGE_NAME = "Stage33 F"
UPDATE_CODENAME = "PRIMER BLOQUE VISIBLE"
UPDATE_SUBTITLE = "Surface real controlado + menu con nombre clave"

def full_update_name():
    return f"{STAGE_NAME} - {UPDATE_CODENAME}"
UPDATE_DESCRIPTION = "Primer chunk visible experimental en ruta Vulkan"
