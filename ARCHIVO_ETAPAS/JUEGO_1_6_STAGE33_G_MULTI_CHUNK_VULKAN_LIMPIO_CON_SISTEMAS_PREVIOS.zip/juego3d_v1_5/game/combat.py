import math

ATTACK_RANGE = 3
ATTACK_DAMAGE = 25

def _hit_enemy(player, enemy, damage=1):
    if hasattr(enemy, "take_hit"):
        enemy.take_hit(damage, player.pos_x, player.pos_z)
    else:
        enemy.health -= ATTACK_DAMAGE

def _in_front_of_player(player, enemy, max_angle_deg=95.0):
    dx = enemy.x - player.pos_x
    dz = enemy.z - player.pos_z
    dist = math.sqrt(dx * dx + dz * dz)
    if dist <= 0.01:
        return True
    yaw = math.radians(player.yaw)
    fx = math.cos(yaw)
    fz = math.sin(yaw)
    dot = (dx / dist) * fx + (dz / dist) * fz
    dot = max(-1.0, min(1.0, dot))
    angle = math.degrees(math.acos(dot))
    return angle <= max_angle_deg

def attack_enemy(player, enemies, locked_target=None, attack_range=ATTACK_RANGE):
    """Ataca primero el objetivo fijado. En tercera persona usa asistencia frontal."""
    hit_any = False

    if locked_target is not None and locked_target in enemies:
        dx = player.pos_x - locked_target.x
        dz = player.pos_z - locked_target.z
        dist = math.sqrt(dx * dx + dz * dz)
        if dist < attack_range + 1.0:
            _hit_enemy(player, locked_target, 1)
            hit_any = True

    if not hit_any:
        for enemy in enemies:
            dx = player.pos_x - enemy.x
            dz = player.pos_z - enemy.z
            dist = math.sqrt(dx * dx + dz * dz)
            assist_range = attack_range + (1.4 if getattr(player, "camera_mode", "first") == "third" else 0.0)
            if dist < assist_range and _in_front_of_player(player, enemy):
                _hit_enemy(player, enemy, 1)
                hit_any = True

    enemies[:] = [e for e in enemies if e.health > 0]
    return hit_any
