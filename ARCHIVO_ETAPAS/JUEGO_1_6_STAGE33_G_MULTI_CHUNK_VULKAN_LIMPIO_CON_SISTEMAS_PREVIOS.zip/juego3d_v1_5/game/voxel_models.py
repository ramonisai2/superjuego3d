
from OpenGL.GL import *
import math
import os

try:
    import pygame
except Exception:
    pygame = None

_PLAYER_SKIN_TEX_ID = None
_PLAYER_SKIN_TEX_W = 1
_PLAYER_SKIN_TEX_H = 1

# Rectangulos (x0, y0, x1, y1) dentro del atlas generado.
# Son aproximados pero estan ajustados a la plantilla creada para este personaje.
PLAYER_SKIN_RECTS = {
    "head": {
        "top": (0, 0, 31, 31),
        "bottom": (34, 0, 65, 31),
        "front": (68, 0, 99, 31),
        "back": (102, 0, 133, 31),
        "left": (136, 0, 167, 31),
        "right": (170, 0, 201, 31),
    },
    "torso": {
        "top": (0, 36, 39, 59),
        "bottom": (42, 36, 81, 59),
        "front": (84, 36, 123, 99),
        "back": (126, 36, 165, 99),
        "left": (168, 36, 199, 99),
        "right": (202, 36, 233, 99),
    },
    "right_arm": {
        "top": (0, 104, 23, 127),
        "bottom": (26, 104, 49, 127),
        "front": (52, 104, 75, 159),
        "back": (78, 104, 101, 159),
        "left": (104, 104, 127, 159),
        "right": (130, 104, 153, 159),
    },
    "left_arm": {
        "top": (0, 104, 23, 127),
        "bottom": (26, 104, 49, 127),
        "front": (156, 104, 179, 159),
        "back": (182, 104, 205, 159),
        "left": (208, 104, 231, 159),
        "right": (232, 104, 255, 159),
    },
    "right_leg": {
        "top": (0, 164, 23, 187),
        "bottom": (26, 164, 49, 187),
        "front": (52, 164, 75, 239),
        "back": (78, 164, 101, 239),
        "left": (104, 164, 127, 239),
        "right": (130, 164, 153, 239),
    },
    "left_leg": {
        "top": (0, 164, 23, 187),
        "bottom": (26, 164, 49, 187),
        "front": (156, 164, 179, 239),
        "back": (182, 164, 205, 239),
        "left": (208, 164, 231, 239),
        "right": (232, 164, 255, 239),
    },
}

def _find_player_skin_path():
    here = os.path.dirname(__file__)
    candidates = [
        os.path.join(here, '..', 'player_skin_texture_atlas.png'),
        os.path.join(os.path.dirname(here), 'player_skin_texture_atlas.png'),
        '/mnt/data/minecraft_character_skin_texture_atlas.png',
    ]
    for path in candidates:
        path = os.path.abspath(path)
        if os.path.exists(path):
            return path
    return None


def _load_player_skin_texture():
    global _PLAYER_SKIN_TEX_ID, _PLAYER_SKIN_TEX_W, _PLAYER_SKIN_TEX_H
    if _PLAYER_SKIN_TEX_ID is not None:
        return _PLAYER_SKIN_TEX_ID
    if pygame is None:
        return None
    skin_path = _find_player_skin_path()
    if not skin_path:
        return None
    try:
        surface = pygame.image.load(skin_path).convert_alpha()
        _PLAYER_SKIN_TEX_W, _PLAYER_SKIN_TEX_H = surface.get_width(), surface.get_height()
        data = pygame.image.tostring(surface, 'RGBA', True)
        tex_id = glGenTextures(1)
        glBindTexture(GL_TEXTURE_2D, tex_id)
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST)
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST)
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP)
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP)
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, _PLAYER_SKIN_TEX_W, _PLAYER_SKIN_TEX_H, 0, GL_RGBA, GL_UNSIGNED_BYTE, data)
        _PLAYER_SKIN_TEX_ID = tex_id
        return tex_id
    except Exception:
        _PLAYER_SKIN_TEX_ID = None
        return None


def _rect_uv(rect):
    x0, y0, x1, y1 = rect
    w = float(_PLAYER_SKIN_TEX_W)
    h = float(_PLAYER_SKIN_TEX_H)
    pad = 1.0
    u0 = (x0 + pad) / w
    u1 = (x1 - pad) / w
    # pygame.image.tostring(..., True) ya voltea verticalmente, asi que usamos v directo.
    v0 = (y0 + pad) / h
    v1 = (y1 - pad) / h
    return (u0, v0, u1, v1)


def draw_textured_box(cx, cy, cz, sx, sy, sz, face_rects, shade_map=None):
    tex_id = _load_player_skin_texture()
    if tex_id is None:
        return False
    if shade_map is None:
        shade_map = {"front":1.0, "back":0.82, "left":0.90, "right":0.90, "top":1.08, "bottom":0.70}
    hx, hy, hz = sx / 2.0, sy / 2.0, sz / 2.0
    x0, x1 = cx - hx, cx + hx
    y0, y1 = cy - hy, cy + hy
    z0, z1 = cz - hz, cz + hz

    def tc(face, p1, p2, p3, p4):
        u0, v0, u1, v1 = _rect_uv(face_rects[face])
        f = max(0.0, min(1.2, float(shade_map.get(face, 1.0))))
        glColor3f(f, f, f)
        glTexCoord2f(u0, v0); glVertex3f(*p1)
        glTexCoord2f(u1, v0); glVertex3f(*p2)
        glTexCoord2f(u1, v1); glVertex3f(*p3)
        glTexCoord2f(u0, v1); glVertex3f(*p4)

    glEnable(GL_TEXTURE_2D)
    glBindTexture(GL_TEXTURE_2D, tex_id)
    glBegin(GL_QUADS)
    tc("front",  (x0,y0,z1), (x1,y0,z1), (x1,y1,z1), (x0,y1,z1))
    tc("back",   (x1,y0,z0), (x0,y0,z0), (x0,y1,z0), (x1,y1,z0))
    tc("left",   (x0,y0,z0), (x0,y0,z1), (x0,y1,z1), (x0,y1,z0))
    tc("right",  (x1,y0,z1), (x1,y0,z0), (x1,y1,z0), (x1,y1,z1))
    tc("top",    (x0,y1,z1), (x1,y1,z1), (x1,y1,z0), (x0,y1,z0))
    tc("bottom", (x0,y0,z0), (x1,y0,z0), (x1,y0,z1), (x0,y0,z1))
    glEnd()
    glDisable(GL_TEXTURE_2D)
    return True

def _shade(color, factor):
    return [max(0.0, min(1.0, c * factor)) for c in color]

def draw_box(cx, cy, cz, sx, sy, sz, color):
    """Caja voxel centrada en coordenadas locales."""
    hx, hy, hz = sx / 2.0, sy / 2.0, sz / 2.0
    x0, x1 = cx - hx, cx + hx
    y0, y1 = cy - hy, cy + hy
    z0, z1 = cz - hz, cz + hz
    top = _shade(color, 1.15)
    front = _shade(color, 1.00)
    side = _shade(color, 0.82)
    back = _shade(color, 0.70)
    bottom = _shade(color, 0.55)
    glBegin(GL_QUADS)
    glColor3fv(front);  glVertex3f(x0,y0,z1); glVertex3f(x1,y0,z1); glVertex3f(x1,y1,z1); glVertex3f(x0,y1,z1)
    glColor3fv(back);   glVertex3f(x1,y0,z0); glVertex3f(x0,y0,z0); glVertex3f(x0,y1,z0); glVertex3f(x1,y1,z0)
    glColor3fv(side);   glVertex3f(x0,y0,z0); glVertex3f(x0,y0,z1); glVertex3f(x0,y1,z1); glVertex3f(x0,y1,z0)
    glColor3fv(side);   glVertex3f(x1,y0,z1); glVertex3f(x1,y0,z0); glVertex3f(x1,y1,z0); glVertex3f(x1,y1,z1)
    glColor3fv(top);    glVertex3f(x0,y1,z1); glVertex3f(x1,y1,z1); glVertex3f(x1,y1,z0); glVertex3f(x0,y1,z0)
    glColor3fv(bottom); glVertex3f(x0,y0,z0); glVertex3f(x1,y0,z0); glVertex3f(x1,y0,z1); glVertex3f(x0,y0,z1)
    glEnd()

def draw_wire_box(cx, cy, cz, sx, sy, sz, color=(0,1,0), line_width=2.0):
    hx, hy, hz = sx / 2.0, sy / 2.0, sz / 2.0
    x0, x1 = cx - hx, cx + hx
    y0, y1 = cy - hy, cy + hy
    z0, z1 = cz - hz, cz + hz
    pts = [(x0,y0,z0),(x1,y0,z0),(x1,y1,z0),(x0,y1,z0),(x0,y0,z1),(x1,y0,z1),(x1,y1,z1),(x0,y1,z1)]
    edges = [(0,1),(1,2),(2,3),(3,0),(4,5),(5,6),(6,7),(7,4),(0,4),(1,5),(2,6),(3,7)]
    glColor3f(*color)
    glLineWidth(line_width)
    glBegin(GL_LINES)
    for a,b in edges:
        glVertex3f(*pts[a]); glVertex3f(*pts[b])
    glEnd()



def draw_shadow_blob(cx, cy, cz, sx, sz, alpha=0.18):
    """Sombra plana y suave para anclar entidades al suelo."""
    glEnable(GL_BLEND)
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA)
    glDepthMask(GL_FALSE)
    glColor4f(0.03, 0.03, 0.04, alpha)
    glBegin(GL_QUADS)
    glVertex3f(cx - sx * 0.5, cy, cz - sz * 0.5)
    glVertex3f(cx + sx * 0.5, cy, cz - sz * 0.5)
    glVertex3f(cx + sx * 0.5, cy, cz + sz * 0.5)
    glVertex3f(cx - sx * 0.5, cy, cz + sz * 0.5)
    glEnd()
    glDepthMask(GL_TRUE)
    glDisable(GL_BLEND)

def render_voxel_humanoid(x, base_y, z, yaw=0.0, body_color=(0.15,0.55,0.20), skin_color=(0.86,0.72,0.58), accent_color=(0.1,0.1,0.1), legendary=False, debug_hitbox=False, selected=False, walk_phase=0.0, move_amount=0.0, swimming=False):
    """Humanoide boxel con orientación y animación básica de caminata/nado."""
    move_amount = max(0.0, min(1.0, float(move_amount)))
    step = math.sin(walk_phase) * move_amount
    step2 = math.sin(walk_phase + math.pi) * move_amount
    lift_a = max(0.0, math.sin(walk_phase)) * 0.07 * move_amount
    lift_b = max(0.0, math.sin(walk_phase + math.pi)) * 0.07 * move_amount

    glPushMatrix()
    draw_shadow_blob(x, base_y + 0.015, z, 0.95, 0.78, 0.16)
    glTranslatef(x, base_y, z)
    glRotatef(yaw, 0, 1, 0)

    # Si nada, el cuerpo va un poco mas bajo e inclinado visualmente con brazos abiertos.
    swim_drop = 0.10 if swimming else 0.0
    swim_arm = 0.16 if swimming else 0.0
    swim_bob = math.sin(walk_phase * 0.75) * 0.035 if swimming else 0.0

    leg_col = _shade(body_color, 0.78)
    boot_col = _shade(accent_color, 0.70)
    glove_col = _shade(skin_color, 0.85)
    strap_col = _shade(accent_color, 0.60)

    # Piernas con pseudo-pasos: se adelantan/atrasan en Z y suben un poco.
    # Más gruesas para que se lean desde la cámara de tercera persona.
    left_z = 0.10 * step
    right_z = 0.10 * step2
    draw_box(-0.18, 0.20 + lift_a, left_z, 0.28, 0.18, 0.34, boot_col)
    draw_box( 0.18, 0.20 + lift_b, right_z, 0.28, 0.18, 0.34, boot_col)
    draw_box(-0.18, 0.54 + lift_a * 0.45, left_z * 0.55, 0.24, 0.54, 0.27, leg_col)
    draw_box( 0.18, 0.54 + lift_b * 0.45, right_z * 0.55, 0.24, 0.54, 0.27, leg_col)
    # Rodilleras / marcas para que no parezcan dos postes lisos.
    draw_box(-0.18, 0.64 + lift_a * 0.45, 0.16 + left_z * 0.55, 0.20, 0.08, 0.045, _shade(accent_color, 0.78))
    draw_box( 0.18, 0.64 + lift_b * 0.45, 0.16 + right_z * 0.55, 0.20, 0.08, 0.045, _shade(accent_color, 0.78))

    # Torso: un poco mas definido, con hombros/cinturon/pecho.
    torso_y = 1.02 - swim_drop + swim_bob
    draw_box(0.0, torso_y, -0.02, 0.78, 0.74, 0.42, body_color)
    draw_box(0.0, torso_y + 0.18, 0.225, 0.34, 0.26, 0.045, accent_color if not legendary else (1.0, 0.80, 0.10))
    draw_box(0.0, torso_y + 0.44, 0.14, 0.42, 0.10, 0.11, _shade(body_color, 0.62))
    draw_box(0.0, torso_y - 0.30, 0.02, 0.84, 0.11, 0.32, _shade(accent_color, 0.74))
    # Correas de mochila al frente.
    draw_box(-0.24, torso_y + 0.05, 0.232, 0.055, 0.54, 0.035, strap_col)
    draw_box( 0.24, torso_y + 0.05, 0.232, 0.055, 0.54, 0.035, strap_col)

    # Brazos opuestos a las piernas. En nado se abren un poco para simular flotación.
    arm_swing_l = -0.12 * step + swim_arm
    arm_swing_r = -0.12 * step2 - swim_arm
    draw_box(-0.53, torso_y - 0.02, arm_swing_l, 0.19, 0.76, 0.23, _shade(body_color, 0.90))
    draw_box( 0.53, torso_y - 0.04, arm_swing_r, 0.20, 0.80, 0.24, _shade(body_color, 0.82))
    draw_box(-0.53, torso_y - 0.45, arm_swing_l + 0.02, 0.18, 0.16, 0.20, glove_col)
    draw_box( 0.53, torso_y - 0.47, arm_swing_r + 0.02, 0.18, 0.16, 0.20, glove_col)
    draw_box( 0.42, torso_y + 0.25, -0.02, 0.22, 0.14, 0.28, _shade(accent_color, 0.82))

    # Cabeza y rostro más claro para saber hacia dónde mira.
    head_y = 1.60 - swim_drop + swim_bob
    draw_box(0.0, head_y, 0.0, 0.43, 0.49, 0.43, skin_color)
    hat_col = accent_color if not legendary else (0.95, 0.72, 0.12)
    draw_box(0.0, head_y + 0.28, -0.02, 0.54, 0.16, 0.47, hat_col)
    draw_box(0.0, head_y + 0.16, 0.18, 0.34, 0.08, 0.075, _shade(hat_col, 0.88))
    draw_box(-0.10, head_y + 0.04, 0.225, 0.06, 0.06, 0.03, (0.03, 0.03, 0.03))
    draw_box( 0.10, head_y + 0.04, 0.225, 0.06, 0.06, 0.03, (0.03, 0.03, 0.03))
    draw_box( 0.00, head_y - 0.06, 0.232, 0.07, 0.09, 0.035, _shade(skin_color, 0.86))
    # Nariz/pequeña dirección frontal.
    draw_box(0.0, head_y - 0.01, 0.255, 0.055, 0.055, 0.055, _shade(skin_color, 0.78))

    # Mochila y detalles laterales para que se vea menos cubo.
    draw_box(0.0, torso_y, -0.27, 0.42, 0.48, 0.14, _shade(accent_color, 0.74))
    draw_box(-0.30, torso_y - 0.14, -0.18, 0.09, 0.24, 0.09, _shade(accent_color, 0.90))
    draw_box( 0.31, torso_y - 0.12, -0.18, 0.08, 0.20, 0.08, _shade(accent_color, 0.82))

    if selected:
        draw_wire_box(0.0, 0.98, 0.0, 1.12, 2.04, 0.98, (0.0, 1.0, 0.0), 2.5)
    if debug_hitbox:
        draw_wire_box(0.0, 0.90, 0.0, 0.62, 1.80, 0.62, (1.0, 0.05, 0.05), 1.5)
    glPopMatrix()

def render_player_avatar(x, base_y, z, yaw=0.0, selected=False, walk_phase=0.0, move_amount=0.0, swimming=False):
    """Jugador principal con mezcla de textura + boxel.
    La textura da identidad de ropa/cara y las piezas boxel agregan volumen.
    """
    move_amount = max(0.0, min(1.0, float(move_amount)))
    step = math.sin(walk_phase) * move_amount
    step2 = math.sin(walk_phase + math.pi) * move_amount
    lift_a = max(0.0, math.sin(walk_phase)) * 0.07 * move_amount
    lift_b = max(0.0, math.sin(walk_phase + math.pi)) * 0.07 * move_amount

    tex_id = _load_player_skin_texture()
    if tex_id is None:
        render_voxel_humanoid(
            x, base_y, z, yaw=yaw,
            body_color=(0.18,0.32,0.70),
            skin_color=(0.88,0.74,0.60),
            accent_color=(0.10,0.12,0.16),
            selected=selected,
            walk_phase=walk_phase,
            move_amount=move_amount,
            swimming=swimming,
        )
        return

    glPushMatrix()
    draw_shadow_blob(x, base_y + 0.015, z, 0.98, 0.80, 0.16)
    glTranslatef(x, base_y, z)
    glRotatef(yaw, 0, 1, 0)

    swim_drop = 0.10 if swimming else 0.0
    swim_arm = 0.16 if swimming else 0.0
    swim_bob = math.sin(walk_phase * 0.75) * 0.035 if swimming else 0.0

    torso_y = 1.03 - swim_drop + swim_bob
    head_y = 1.60 - swim_drop + swim_bob
    left_z = 0.10 * step
    right_z = 0.10 * step2
    arm_swing_l = -0.12 * step + swim_arm
    arm_swing_r = -0.12 * step2 - swim_arm

    # Paleta boxel/accesorios.
    dark = (0.08, 0.10, 0.13)
    steel = (0.28, 0.31, 0.35)
    brown = (0.31, 0.21, 0.12)
    gold = (0.68, 0.57, 0.22)
    blue = (0.15, 0.30, 0.60)
    skin = (0.74, 0.56, 0.37)
    hair = (0.10, 0.09, 0.08)

    # Piernas texturadas + refuerzos boxel.
    draw_textured_box(-0.19, 0.20 + lift_a, left_z, 0.29, 0.18, 0.35, PLAYER_SKIN_RECTS["left_leg"])
    draw_textured_box( 0.19, 0.20 + lift_b, right_z, 0.29, 0.18, 0.35, PLAYER_SKIN_RECTS["right_leg"])
    draw_textured_box(-0.19, 0.55 + lift_a * 0.45, left_z * 0.55, 0.25, 0.55, 0.28, PLAYER_SKIN_RECTS["left_leg"])
    draw_textured_box( 0.19, 0.55 + lift_b * 0.45, right_z * 0.55, 0.25, 0.55, 0.28, PLAYER_SKIN_RECTS["right_leg"])
    draw_box(-0.19, 0.12 + lift_a, left_z, 0.31, 0.09, 0.37, dark)
    draw_box( 0.19, 0.12 + lift_b, right_z, 0.31, 0.09, 0.37, dark)
    draw_box(-0.19, 0.66 + lift_a * 0.45, 0.12 + left_z * 0.40, 0.22, 0.08, 0.05, steel)
    draw_box( 0.19, 0.66 + lift_b * 0.45, 0.12 + right_z * 0.40, 0.22, 0.08, 0.05, steel)
    draw_box(-0.19, 0.37 + lift_a * 0.25, 0.15 + left_z * 0.45, 0.19, 0.06, 0.04, gold)
    draw_box( 0.19, 0.37 + lift_b * 0.25, 0.15 + right_z * 0.45, 0.19, 0.06, 0.04, gold)

    # Torso principal texturizado.
    draw_textured_box(0.0, torso_y, -0.02, 0.76, 0.74, 0.42, PLAYER_SKIN_RECTS["torso"])
    # Volumen boxel encima del torso.
    draw_box(0.0, torso_y + 0.16, 0.20, 0.42, 0.20, 0.05, steel)
    draw_box(0.0, torso_y - 0.03, 0.19, 0.56, 0.28, 0.04, steel)
    draw_box(0.0, torso_y - 0.28, 0.02, 0.84, 0.10, 0.33, brown)
    draw_box(0.0, torso_y - 0.28, 0.20, 0.12, 0.11, 0.05, gold)
    draw_box(-0.23, torso_y + 0.06, 0.225, 0.055, 0.54, 0.035, brown)
    draw_box( 0.23, torso_y + 0.06, 0.225, 0.055, 0.54, 0.035, brown)
    draw_box(0.0, torso_y + 0.02, -0.29, 0.36, 0.42, 0.14, brown)
    draw_box(0.0, torso_y - 0.04, -0.40, 0.20, 0.16, 0.07, dark)
    draw_box(0.0, torso_y + 0.34, -0.24, 0.24, 0.08, 0.06, steel)

    # Hombros boxel para que no se vea plano.
    draw_box(-0.39, torso_y + 0.25, 0.0, 0.17, 0.14, 0.24, steel)
    draw_box( 0.39, torso_y + 0.25, 0.0, 0.17, 0.14, 0.24, steel)

    # Brazos texturizados + brazaletes.
    draw_textured_box(-0.54, torso_y - 0.03, arm_swing_l, 0.18, 0.76, 0.22, PLAYER_SKIN_RECTS["left_arm"])
    draw_textured_box( 0.54, torso_y - 0.04, arm_swing_r, 0.18, 0.78, 0.22, PLAYER_SKIN_RECTS["right_arm"])
    draw_box(-0.54, torso_y + 0.20, arm_swing_l, 0.21, 0.11, 0.25, steel)
    draw_box( 0.54, torso_y + 0.20, arm_swing_r, 0.21, 0.11, 0.25, steel)
    draw_box(-0.54, torso_y - 0.18, arm_swing_l + 0.01, 0.15, 0.07, 0.24, gold)
    draw_box( 0.54, torso_y - 0.19, arm_swing_r + 0.01, 0.15, 0.07, 0.24, gold)
    draw_box(-0.54, torso_y - 0.46, arm_swing_l + 0.02, 0.18, 0.14, 0.19, skin)
    draw_box( 0.54, torso_y - 0.48, arm_swing_r + 0.02, 0.18, 0.14, 0.19, skin)

    # Cabeza texturizada + volumen de cabello/capucha.
    draw_textured_box(0.0, head_y, 0.0, 0.43, 0.49, 0.43, PLAYER_SKIN_RECTS["head"])
    draw_box(0.0, head_y + 0.24, 0.0, 0.47, 0.08, 0.47, hair)
    draw_box(0.0, head_y + 0.05, -0.18, 0.46, 0.34, 0.09, dark)
    draw_box(-0.19, head_y + 0.02, 0.0, 0.05, 0.28, 0.40, hair)
    draw_box( 0.19, head_y + 0.02, 0.0, 0.05, 0.28, 0.40, hair)
    draw_box(0.0, head_y - 0.02, 0.255, 0.05, 0.05, 0.05, skin)
    draw_box(0.0, head_y - 0.26, 0.0, 0.16, 0.07, 0.12, skin)

    if swimming:
        draw_box(0.0, torso_y + 0.05, -0.46, 0.52, 0.08, 0.08, blue)

    if selected:
        draw_wire_box(0.0, 0.98, 0.0, 1.12, 2.04, 0.98, (0.0, 1.0, 0.0), 2.5)
    glPopMatrix()

def render_voxel_slime(x, base_y, z, yaw=0.0, body_color=(0.85,0.10,0.12), eye_color=(1,1,1), pupil_color=(0.08,0.02,0.02), selected=False, debug_hitbox=False, body_scale=1.0, aggro=0.0, squish_phase=0.0, is_boss=False):
    """Slime boxel con frente claro, patas endebles y cuerpo gelatinoso."""
    glPushMatrix()
    draw_shadow_blob(x, base_y + 0.012, z, 0.95 * body_scale, 0.82 * body_scale, 0.13)
    glTranslatef(x, base_y, z)
    glRotatef(yaw, 0, 1, 0)

    wobble = math.sin(squish_phase)
    body_alpha = 0.52 if not is_boss else 0.62
    leg_h = (0.16 + 0.34 * aggro + 0.03 * wobble) * body_scale
    body_y = leg_h + (0.44 + 0.04 * wobble) * body_scale
    body_h = (0.74 - 0.07 * wobble) * body_scale
    body_w = (0.90 + 0.05 * wobble) * body_scale
    body_d = (0.86 + 0.04 * wobble) * body_scale

    leg_color = _shade(body_color, 0.68)
    spread = 0.25 * body_scale + 0.06 * aggro
    leg_w = 0.10 * body_scale
    # Patitas delgadas y algo torcidas para que se vean frágiles.
    draw_box(-spread, leg_h * 0.5, -spread - 0.03 * wobble, leg_w, leg_h, leg_w, leg_color)
    draw_box( spread, leg_h * 0.5, -spread + 0.02 * wobble, leg_w, leg_h, leg_w, leg_color)
    draw_box(-spread + 0.02 * wobble, leg_h * 0.5, spread, leg_w, leg_h, leg_w, leg_color)
    draw_box( spread - 0.03 * wobble, leg_h * 0.5, spread, leg_w, leg_h, leg_w, leg_color)

    # Cuerpo translúcido como gelatina.
    draw_box_alpha(0.0, body_y, 0.0, body_w, body_h, body_d, body_color, body_alpha)
    # Núcleo interno tenue para que se vea a través.
    draw_box_alpha(0.0, body_y - 0.02 * body_scale, 0.0, body_w * 0.55, body_h * 0.48, body_d * 0.55, _shade(body_color, 1.15), body_alpha * 0.30)

    eye_z = body_d * 0.52
    eye_y = body_y + 0.10 * body_scale
    draw_box(-0.18 * body_scale, eye_y, eye_z, 0.13 * body_scale, 0.10 * body_scale, 0.03 * body_scale, eye_color)
    draw_box( 0.18 * body_scale, eye_y, eye_z, 0.13 * body_scale, 0.10 * body_scale, 0.03 * body_scale, eye_color)
    draw_box(-0.18 * body_scale, eye_y, eye_z + 0.012 * body_scale, 0.05 * body_scale, 0.05 * body_scale, 0.02 * body_scale, pupil_color)
    draw_box( 0.18 * body_scale, eye_y, eye_z + 0.012 * body_scale, 0.05 * body_scale, 0.05 * body_scale, 0.02 * body_scale, pupil_color)
    draw_box(0.0, body_y - 0.10 * body_scale, eye_z, 0.20 * body_scale, 0.05 * body_scale, 0.03 * body_scale, _shade(body_color, 0.42))

    if is_boss:
        draw_box_alpha(0.0, body_y + body_h * 0.58, 0.0, 0.54 * body_scale, 0.12 * body_scale, 0.54 * body_scale, (0.92, 0.16, 0.90), 0.72)

    total_h = leg_h + body_h
    if selected:
        draw_wire_box(0.0, total_h * 0.5, 0.0, 1.10 * body_scale, total_h + 0.18 * body_scale, 1.10 * body_scale, (0.1, 1.0, 0.1), 2.2)
    if debug_hitbox:
        draw_wire_box(0.0, total_h * 0.5, 0.0, 0.86 * body_scale, total_h, 0.86 * body_scale, (1.0, 0.05, 0.05), 1.5)
    glPopMatrix()


def draw_box_alpha(cx, cy, cz, sx, sy, sz, color, alpha=0.6):
    """Caja translúcida simple para materiales gelatinosos."""
    hx, hy, hz = sx / 2.0, sy / 2.0, sz / 2.0
    x0, x1 = cx - hx, cx + hx
    y0, y1 = cy - hy, cy + hy
    z0, z1 = cz - hz, cz + hz
    top = _shade(color, 1.12)
    front = _shade(color, 1.00)
    side = _shade(color, 0.82)
    back = _shade(color, 0.72)
    bottom = _shade(color, 0.58)
    glEnable(GL_BLEND)
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA)
    glDepthMask(GL_FALSE)
    glBegin(GL_QUADS)
    glColor4f(front[0], front[1], front[2], alpha);  glVertex3f(x0,y0,z1); glVertex3f(x1,y0,z1); glVertex3f(x1,y1,z1); glVertex3f(x0,y1,z1)
    glColor4f(back[0], back[1], back[2], alpha);   glVertex3f(x1,y0,z0); glVertex3f(x0,y0,z0); glVertex3f(x0,y1,z0); glVertex3f(x1,y1,z0)
    glColor4f(side[0], side[1], side[2], alpha);   glVertex3f(x0,y0,z0); glVertex3f(x0,y0,z1); glVertex3f(x0,y1,z1); glVertex3f(x0,y1,z0)
    glColor4f(side[0], side[1], side[2], alpha);   glVertex3f(x1,y0,z1); glVertex3f(x1,y0,z0); glVertex3f(x1,y1,z0); glVertex3f(x1,y1,z1)
    glColor4f(top[0], top[1], top[2], alpha);    glVertex3f(x0,y1,z1); glVertex3f(x1,y1,z1); glVertex3f(x1,y1,z0); glVertex3f(x0,y1,z0)
    glColor4f(bottom[0], bottom[1], bottom[2], alpha); glVertex3f(x0,y0,z0); glVertex3f(x1,y0,z0); glVertex3f(x1,y0,z1); glVertex3f(x0,y0,z1)
    glEnd()
    glDepthMask(GL_TRUE)
    glDisable(GL_BLEND)


def render_slime_puddle(x, y, z, color=(0.9,0.1,0.12), alpha=0.4, scale=1.0):
    glPushMatrix()
    glTranslatef(x, y + 0.02, z)
    draw_box_alpha(0.0, 0.0, 0.0, 0.75 * scale, 0.05, 0.62 * scale, color, alpha)
    draw_box_alpha(0.10 * scale, 0.005, -0.08 * scale, 0.35 * scale, 0.03, 0.28 * scale, _shade(color, 1.08), alpha * 0.8)
    glPopMatrix()
