from motor_juegos import r2d

# UI 2D para ventana OPENGL.
# Importante: no usamos pygame.display.get_surface().blit() porque en modo OPENGL
# suele no aparecer o queda tapado por el render 3D.

def _panel(x, y, w, h):
    r2d.draw_rect_2d(x, y, w, h, (0.02, 0.02, 0.025))
    r2d.draw_rect_2d(x + 2, y + 2, w - 4, h - 4, (0.05, 0.06, 0.07))

def draw_ui(player):
    _panel(14, 14, 235, 122)
    r2d.draw_text_2d(f'Vida: {int(player.health)}', 24, 26, (255, 255, 255))
    r2d.draw_text_2d(f'Stamina: {int(player.stamina)}', 24, 52, (220, 255, 220))
    r2d.draw_text_2d(f'Hambre: {int(player.hunger)}', 24, 78, (255, 230, 180))
    modo = '3ra persona' if getattr(player, 'camera_mode', 'first') == 'third' else '1ra persona'
    r2d.draw_text_2d(f'Cam: {modo}  V cambia / B distancia / Q fijar / TAB cambiar', 24, 104, (210, 225, 255))


def draw_npc_label(name):
    if not name:
        return
    _panel(14, 112, 320, 34)
    r2d.draw_text_2d(name, 24, 121, (200, 255, 200))


def draw_npc_prompt(prompt):
    if not prompt:
        return
    _panel(14, 152, 420, 34)
    r2d.draw_text_2d(prompt, 24, 161, (255, 255, 200))


def draw_npc_description(description):
    if not description:
        return
    _panel(14, 192, 470, 34)
    r2d.draw_text_2d(description[:62], 24, 201, (200, 240, 255))


def draw_npc_dialog(dialog):
    if not dialog:
        return
    _panel(14, 232, 520, 34)
    r2d.draw_text_2d(dialog[:70], 24, 241, (200, 255, 200))


def draw_npc_world_label(name, x, y):
    if not name or x is None or y is None:
        return
    # Etiqueta aproximada centrada. Evitamos medir texto para mantenerlo simple.
    w = max(120, min(360, len(name) * 11))
    h = 30
    _panel(int(x - w // 2), int(y - h - 8), w, h)
    r2d.draw_text_2d(name, int(x - w // 2 + 8), int(y - h), (180, 255, 180))



def draw_z_target_ui(target, target_type):
    if target is None:
        return

    if target_type == "enemy":
        name = "SLIME FIJADO"
        hp = max(0, getattr(target, "health", 0))
        max_hp = max(1, getattr(target, "max_health", 2))
        subtitle = f"Vida: {hp}/{max_hp}"
        color = (255, 120, 120)
        ratio = max(0.0, min(1.0, hp / max_hp))
    else:
        name = "NPC FIJADO"
        subtitle = getattr(target, "nombre", "Objetivo")
        color = (180, 255, 180)
        ratio = 1.0

    w = 360
    h = 68
    x = 1280 // 2 - w // 2
    y = 22
    _panel(x, y, w, h)
    r2d.draw_text_2d("Q soltar   TAB cambiar", x + 16, y + 8, (255, 235, 130))
    r2d.draw_text_2d(f"{name}  {subtitle}", x + 16, y + 30, color)

    bar_x = x + 16
    bar_y = y + 54
    bar_w = w - 32
    r2d.draw_rect_2d(bar_x, bar_y, bar_w, 6, (0.10, 0.05, 0.05))
    if target_type == "enemy":
        r2d.draw_rect_2d(bar_x, bar_y, int(bar_w * ratio), 6, (0.95, 0.12, 0.10))
    else:
        r2d.draw_rect_2d(bar_x, bar_y, int(bar_w * ratio), 6, (0.25, 0.85, 0.35))

def draw_z_target_marker(screen_pos):
    if not screen_pos:
        return
    x, y = int(screen_pos[0]), int(screen_pos[1])
    size = 44
    col = (1.0, 0.82, 0.12)

    r2d.draw_rect_2d(x - size, y - size, 18, 3, col)
    r2d.draw_rect_2d(x - size, y - size, 3, 18, col)
    r2d.draw_rect_2d(x + size - 18, y - size, 18, 3, col)
    r2d.draw_rect_2d(x + size - 3, y - size, 3, 18, col)
    r2d.draw_rect_2d(x - size, y + size - 3, 18, 3, col)
    r2d.draw_rect_2d(x - size, y + size - 18, 3, 18, col)
    r2d.draw_rect_2d(x + size - 18, y + size - 3, 18, 3, col)
    r2d.draw_rect_2d(x + size - 3, y + size - 18, 3, 18, col)


def draw_world_context(player):
    ctx = getattr(player, "world_context", None)
    if not ctx:
        return
    y = 144
    _panel(14, y, 370, 110)
    swim = "  |  NADANDO" if getattr(player, "is_swimming", False) else ""
    r2d.draw_text_2d(f"Zona: {ctx.get('feature','?')}{swim}", 24, y + 10, (180, 235, 255))
    r2d.draw_text_2d(f"Bioma: {ctx.get('biome','?')}", 24, y + 36, (210, 255, 210))
    r2d.draw_text_2d(f"Altura: {ctx.get('layer','?')}", 24, y + 62, (255, 235, 170))
    if ctx.get('in_water'):
        r2d.draw_text_2d(f"Profundidad agua: {ctx.get('water_depth',0):.2f}", 24, y + 86, (150, 210, 255))
    else:
        r2d.draw_text_2d(f"Cuenca lago: {ctx.get('lake_basin',0):.2f}  Meseta: {ctx.get('mesa_strength',0):.2f}", 24, y + 86, (220, 220, 220))
