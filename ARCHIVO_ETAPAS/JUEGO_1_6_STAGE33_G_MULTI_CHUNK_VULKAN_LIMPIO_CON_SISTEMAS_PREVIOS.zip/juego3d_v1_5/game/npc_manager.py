
import math
import random

FIRST_NAMES = ["Roy","Bolvo","Runia","Tergul","Aldor","Rokkan","Mork"]
TITLES = ["El Calvo","Rompepiedras","El Ocupado","El Errante"]

class NPC:
    def __init__(self, seed, x=0, z=0, y=0):
        r = random.Random(seed)
        self.id = seed
        self.x = x
        self.y = y
        self.z = z
        self.spawn_x = x
        self.spawn_z = z
        self.nombre = r.choice(FIRST_NAMES)
        self.titulo = r.choice(TITLES)
        self.daño = r.randint(8,18)
        self.hostilidad = r.randint(0,100)
        self.height = 1.85
        self.collider_size = (0.62, 1.80, 0.62)
        self.visual_size = (1.15, 2.10, 1.00)
        self.yaw = 0.0
        self.profession = r.choice(["recolector", "viajero", "guardia", "mercader"])
        self.speed = 1.2 + r.random() * 0.8
        self.wander_radius = 10.0
        self.direction = r.uniform(0, 2 * math.pi)
        self.wander_timer = 0.0
        self.wander_change = 1.5 + r.random() * 1.5
        self.memoria = 0
        self.highlight = False
        self.terrain_height_func = None
        self.dialogos = [
            "Esta zona ha cambiado mucho.",
            "No todos los viajeros son de fiar.",
            "Si necesitas agua, ve hacia el oeste.",
            "No me molesten cuando estoy ocupado."
        ]
        self.descripcion = r.choice([
            "Un viajero de paso.",
            "Parece conocer estas tierras.",
            "Tiene una mirada cansada.",
            "Anda con cuidado, lleva cosas valiosas."
        ]) + f" Profesión: {self.profession}."
        self.target_x = self.x
        self.target_z = self.z

    def update(self, dt):
        if self.terrain_height_func:
            self.wander_timer += dt
            if self.wander_timer >= self.wander_change or math.hypot(self.target_x - self.x, self.target_z - self.z) < 0.3:
                self.wander_timer = 0.0
                self.wander_change = 1.5 + random.random() * 2.5
                self.direction += random.uniform(-math.pi / 2, math.pi / 2)
                radius = random.uniform(2.0, self.wander_radius)
                self.target_x = self.spawn_x + math.cos(self.direction) * radius
                self.target_z = self.spawn_z + math.sin(self.direction) * radius

            dx = self.target_x - self.x
            dz = self.target_z - self.z
            dist = math.hypot(dx, dz)
            if dist > 0.05:
                step = self.speed * dt
                move_x = dx / dist * min(step, dist)
                move_z = dz / dist * min(step, dist)
                self.x += move_x
                self.z += move_z
                self.yaw = math.degrees(math.atan2(move_x, move_z))

            # Mantener dentro del radio para que no se pierda
            dxs = self.x - self.spawn_x
            dzs = self.z - self.spawn_z
            if math.hypot(dxs, dzs) > self.wander_radius:
                ang = math.atan2(dzs, dxs) + math.pi
                self.x = self.spawn_x + math.cos(ang) * self.wander_radius
                self.z = self.spawn_z + math.sin(ang) * self.wander_radius
                self.direction = ang

            self.y = self.terrain_height_func(self.x, self.z) + self.height / 2

    def render(self, highlight=False, debug_hitbox=False):
        from game.voxel_models import render_voxel_humanoid
        base_y = self.y - self.height / 2.0
        if hasattr(self, "admin_color"):
            body = self.admin_color
        else:
            # Color por profesión/hostilidad. Mantiene identidad sin usar modelos copiados.
            if self.profession == "mercader":
                body = (0.18, 0.46, 0.72)
            elif self.profession == "guardia" or self.hostilidad > 70:
                body = (0.56, 0.16, 0.14)
            elif self.profession == "recolector":
                body = (0.22, 0.48, 0.24)
            else:
                body = (0.42, 0.34, 0.24)
        legendary = bool(getattr(self, "is_legendary", False))
        accent = (0.08, 0.08, 0.08) if not legendary else (1.0, 0.78, 0.10)
        render_voxel_humanoid(
            self.x, base_y, self.z,
            yaw=self.yaw,
            body_color=body,
            skin_color=(0.88, 0.74, 0.60),
            accent_color=accent,
            legendary=legendary,
            debug_hitbox=debug_hitbox,
            selected=highlight,
        )

    def interactuar(self):
        self.memoria += 1
        if self.memoria == 1:
            return f"Soy {self.nombre} {self.titulo}. ¿Qué necesitas?"
        if self.memoria == 2:
            return "No me gusta que me interrumpan. Habla rápido."
        if self.memoria == 3:
            return "He visto cosas extrañas en esta zona." if self.hostilidad < 50 else "No confío en extraños como tú."
        return self.dialogos[(self.memoria - 4) % len(self.dialogos)]


def generar_npcs_chunk(cx, cz, semilla):
    r = random.Random((cx*92821) ^ (cz*68917) ^ semilla)
    npcs = []
    cantidad = r.randint(0, 3)
    for i in range(cantidad):
        npcs.append(NPC(r.randint(1,999999),
                        cx*100 + r.randint(0,99),
                        cz*100 + r.randint(0,99)))
    return npcs
