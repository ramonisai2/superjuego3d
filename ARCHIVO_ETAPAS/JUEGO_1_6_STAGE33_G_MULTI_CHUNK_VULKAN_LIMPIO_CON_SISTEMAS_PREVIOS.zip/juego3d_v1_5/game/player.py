from motor_juegos import FirstPersonCamera
from game.debug_log import log_event, log_exception

class Player(FirstPersonCamera):
    def __init__(self, x, y, z, terrain_height_func):
        super().__init__(x, y, z)
        self.health = 100
        self.hunger = 100
        self.stamina = 100
        self.inventory = []
        self.terrain_func = terrain_height_func
        self.respawn_x = x
        self.respawn_z = z

    def take_damage(self, amount):
        self.health -= amount
        if self.health <= 0:
            self.respawn()

    def respawn(self):
        rx = float(getattr(self, "respawn_x", self.pos_x))
        rz = float(getattr(self, "respawn_z", self.pos_z))
        try:
            suelo = self.terrain_func(rx, rz)
        except Exception as exc:
            log_exception("PLAYER_RESPAWN_TERRAIN_ERROR", exc)
            rx, rz = 0.0, 0.0
            suelo = self.terrain_func(0, 0)
        self.pos_x = rx
        self.pos_z = rz
        self.pos_y = suelo + self.player_height + 0.08
        self.health = 100
        self.stamina = 100
        self.hunger = 100
        self.velocity_y = 0
        self.is_grounded = True
        self._last_safe_x = self.pos_x
        self._last_safe_y = self.pos_y
        self._last_safe_z = self.pos_z
        log_event("PLAYER_RESPAWN_DONE", x=self.pos_x, y=self.pos_y, z=self.pos_z)
        print("[RESPAWN] Jugador ha revivido.")
